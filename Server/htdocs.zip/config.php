<?php
	define("DB_HOST", "localhost");
	define("DB_USER", "root");
	define("DB_PASSWORD", "zmzm1004");
	define("DB_NAME", "donate");

	define("GOOGLE_API_KEY", "AIzaSyBjyDZGsMWYRnOLEreCy4kD0VX9EDn8bLA"); 

?>